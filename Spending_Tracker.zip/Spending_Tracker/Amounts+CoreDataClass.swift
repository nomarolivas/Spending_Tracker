//
//  Amounts+CoreDataClass.swift
//  Spending_Tracker
//
//  Created by Nomar Olivas on 5/9/22.
//
//

import Foundation
import CoreData

@objc(Amounts)
public class Amounts: NSManagedObject {

}
